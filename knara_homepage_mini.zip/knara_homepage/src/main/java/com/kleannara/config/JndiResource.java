package com.kleannara.config;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JndiResource {

    @Bean
    public TomcatServletWebServerFactory tomcatFactory() {
        return new TomcatServletWebServerFactory() {
            @Override
            protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
                tomcat.enableNaming();
                return super.getTomcatWebServer(tomcat);
            }

            @Override
            protected void postProcessContext(Context context) {
                context.getNamingResources().addResource(getResource());
            }
        };
    }

    public ContextResource getResource() {
        ContextResource resource = new ContextResource();
        resource.setName("jndi/mariadb"); // 사용될 jndi 이름
        resource.setType("javax.sql.DataSource");
        resource.setAuth("Container");
        resource.setProperty("factory", "org.apache.commons.dbcp2.BasicDataSourceFactory");

        // datasource 정보
        resource.setProperty("driverClassName", "net.sf.log4jdbc.sql.jdbcapi.DriverSpy");

        // PROD
//        resource.setProperty("url", "jdbc:log4jdbc:mariadb://10.41.84.93:33306/kleannara");
//        resource.setProperty("username", "kleandb");
//        resource.setProperty("password", "KleanMar!aDB@");
        
        // DEV
        resource.setProperty("url", "jdbc:log4jdbc:mariadb://10.41.185.147:33306/kleannara");
        resource.setProperty("username", "kleandb");
        resource.setProperty("password", "kleandb@@");

        return resource;
    }
}